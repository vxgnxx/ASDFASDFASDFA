/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cadastrodecarros;

/**
 *
 * @author aluno
 */
public class Moto extends Veiculo {
    private int cilindradas;

    // Construtor
    public Moto(double velocidadeMaxima, double preco, double taxaIPVA, int cilindradas) {
        super(velocidadeMaxima, preco, taxaIPVA);
        this.cilindradas = cilindradas;
    }
    
     public int getCilindradas() {
        return cilindradas;
    }


    // calculaIPVA
    @Override
    public double calculaIPVA() {
        return getPreco() * (getTaxaIPVA() / 100);
    }

    @Override
    public String exibeInfo() {
        return "Veículo[Moto] : " + super.exibeInfo() + " – Cilindradas: " + cilindradas + "cc.";
    }
}
