/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cadastrodecarros;

/**
 *
 * @author aluno
 */
public class Caminhao extends Veiculo {
    private double peso;

    // Construtor
    public Caminhao(double velocidadeMaxima, double preco, double taxaIPVA, double peso) {
        super(velocidadeMaxima, preco, taxaIPVA);
        this.peso = peso;
    }
    
    public double getPeso() {
        return peso;
    }

    // calculaIPVA
    @Override
    public double calculaIPVA() {
        return getPreco() * (getTaxaIPVA() / 100);
    }

    @Override
    public String exibeInfo() {
        return "Veículo[Caminhão] : " + super.exibeInfo() + " – Peso: " + peso + "T.";
    }
}

