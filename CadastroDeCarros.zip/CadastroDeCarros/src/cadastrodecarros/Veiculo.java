/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cadastrodecarros;

/**
 *
 * @author aluno
 */
     public abstract class Veiculo {
    private double velocidadeMaxima;
    private double preco;
    private double taxaIPVA;

    // Construtor
    public Veiculo(double velocidadeMaxima, double preco, double taxaIPVA) {
        this.velocidadeMaxima = velocidadeMaxima;
        this.preco = preco;
        this.taxaIPVA = taxaIPVA;
    }

    // Métodos Getters
    public double getVelocidadeMaxima() {
        return velocidadeMaxima;
    }

    public double getPreco() {
        return preco;
    }

    public double getTaxaIPVA() {
        return taxaIPVA;
    }

    // Método abstrato para calcular o IPVA
    public abstract double calculaIPVA();

    // Método para exibir informações do veículo
    public String exibeInfo() {
        return "Velocidade Máxima: " + velocidadeMaxima + " km/h – Preço: R$ " + preco + " – Taxa Base para o IPVA: " + taxaIPVA + " – Valor do Imposto: R$ " + String.format("%.2f", calculaIPVA()) + ".";
    }
}




