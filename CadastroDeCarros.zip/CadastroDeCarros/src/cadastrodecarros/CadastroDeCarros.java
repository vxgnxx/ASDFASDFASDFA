/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package cadastrodecarros;

/**
 *
 * @author aluno
 */
public class CadastroDeCarros {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
         // Array de 12 veículos

        Veiculo[] veiculos = new Veiculo[12];

        // Carro 1
        veiculos[0] = new Carro(120.0, 15000.00, 2.5, "Preto");

        // Carro 2
        veiculos[1] = new Carro(130.0, 22000.00, 2.5, "Branco");

        // Carro 3
        veiculos[2] = new Carro(110.0, 18000.00, 2.5, "Vermelho");

        // Carro 4
        veiculos[3] = new Carro(140.0, 25000.00, 2.5, "Azul");

        // Caminhao 1
        veiculos[4] = new Caminhao(90.0, 70000.00, 1.5, 5.0);

        // Caminhao 2
        veiculos[5] = new Caminhao(85.0, 95000.00, 1.5, 8.0);

        // Caminhao 3
        veiculos[6] = new Caminhao(95.0, 120000.00, 1.5, 10.0);

        // Caminhao 4
        veiculos[7] = new Caminhao(80.0, 80000.00, 1.5, 6.5);

        // Moto 1
        veiculos[8] = new Moto(280.0, 55000.00, 2.0, 1200);

        // Moto 2
        veiculos[9] = new Moto(290.0, 60000.00, 2.0, 1500);

        // Moto 3
        veiculos[10] = new Moto(260.0, 48000.00, 2.0, 1000);

        // Moto 4
        veiculos[11] = new Moto(300.0, 65000.00, 2.0, 1300);
        
        exibeInfoVeiculo(veiculos);
    }


      public static void exibeInfoVeiculo(Veiculo[] veiculos) {
        for (int i = 0; i < veiculos.length; i++) {
            // Verificar o tipo de veículos e imprimir o que é pedido de cada
            if (veiculos[i] instanceof Carro) {
                Carro carro = (Carro) veiculos[i];
                System.out.println("Veículo[" + i + "] : Cor: " + carro.getCor() +
                        " – Velocidade Máxima: " + carro.getVelocidadeMaxima() + " km/h – Preço: R$ " + carro.getPreco() +
                        " – Taxa Base para o IPVA: " + carro.getTaxaIPVA() + " – Valor do Imposto: R$ " + String.format("%.2f", carro.calculaIPVA()) + ".");
            } else if (veiculos[i] instanceof Caminhao) {
                Caminhao caminhao = (Caminhao) veiculos[i];
                System.out.println("Veículo[" + i + "] : Peso: " + caminhao.getPeso() + "T – Velocidade Máxima: " + caminhao.getVelocidadeMaxima() +
                        " km/h – Preço: R$ " + caminhao.getPreco() + " – Taxa Base para o IPVA: " + caminhao.getTaxaIPVA() +
                        " – Valor do Imposto: R$ " + String.format("%.2f", caminhao.calculaIPVA()) + ".");
            } else if (veiculos[i] instanceof Moto) {
                Moto moto = (Moto) veiculos[i];
                System.out.println("Veículo[" + i + "] : Cilindradas: " + moto.getCilindradas() + "cc – Velocidade Máxima: " + moto.getVelocidadeMaxima() +
                        " km/h – Preço: R$ " + moto.getPreco() + " – Taxa Base para o IPVA: " + moto.getTaxaIPVA() +
                        " – Valor do Imposto: R$ " + String.format("%.2f", moto.calculaIPVA()) + ".");
            }
        }
    }
}