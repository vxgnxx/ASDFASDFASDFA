/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cadastrodecarros;

/**
 *
 * @author aluno
 */
public class Carro extends Veiculo {
    private String cor;

    // Construtor
    public Carro(double velocidadeMaxima, double preco, double taxaIPVA, String cor) {
        super(velocidadeMaxima, preco, taxaIPVA);
        this.cor = cor;
    }
    
    public String getCor(){
        return cor;
    }

    // calculaIPVA
    @Override
    public double calculaIPVA() {
        return getPreco() * (getTaxaIPVA() / 100);
    }

    @Override
    public String exibeInfo() {
        return "Veículo[Carro] : " + super.exibeInfo() + " - Cor: " + cor;
    }
}
